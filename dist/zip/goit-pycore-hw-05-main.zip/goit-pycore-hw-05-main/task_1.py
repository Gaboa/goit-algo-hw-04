def caching_fibonacci(n: int) -> int:
    cache = {}

    def fibonacci(n: int) -> int:
        if n <= 1:
            return n
        if n in cache:
            return cache[n]

        cache[n] = fibonacci(n - 1) + fibonacci(n - 2)

        return cache[n]

    return fibonacci(n)

print(caching_fibonacci(10))
print(caching_fibonacci(15))
print(caching_fibonacci(30))