from typing import Iterator
import re

def generator_numbers(text: str) -> Iterator[float]:
    numbers = re.findall(r'(?<= )\d+\.\d{2}(?= )', text)

    def num_generator():
        for number in numbers:
            yield float(number)

    return num_generator()

def sum_profit(text: str, gen_func) -> float:
    return sum(gen_func(text))

test_str_1 = "Загальний дохід працівника складається з декількох частин: 1000.01 як основний дохід, доповнений додатковими надходженнями 27.45 і 324.00 доларів."
test_str_2 = "The values are 3.14 and 2.71 in the text."
print(sum_profit(test_str_1, generator_numbers))
print(sum_profit(test_str_2, generator_numbers))