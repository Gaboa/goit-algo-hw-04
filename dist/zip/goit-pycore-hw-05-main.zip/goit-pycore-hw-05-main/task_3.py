import sys
from collections import Counter, namedtuple

LogLine = namedtuple("LogLine", ["date", "time", "level", "message"])

def load_logs(file_path: str) -> list[str]:
    try: 
        with open(file_path, "r", encoding="utf-8") as file:
            return file.readlines()

    except (UnicodeDecodeError, FileNotFoundError) as e:
        print(f"Error reading file: {e}")
        return []

def parse_log_line(line: str) -> LogLine | None:
    try:
        date, time, level, message = line.strip().split(" ", 3)
        return LogLine(date, time, level, message)

    except ValueError as e:
        print(f"Error parsing line: {e}")

def parse_logs(file_path: str) -> list[LogLine]:
    parsed_logs = []
    log_lines = load_logs(file_path)
    for line in log_lines:
        log_line = parse_log_line(line)
        if log_line:
            parsed_logs.append(log_line)

    return parsed_logs

def filter_logs_by_level(logs: list[LogLine], level: str) -> list[LogLine]:
    filtered_logs = []
    for log in logs:
        if log.level == level.upper():
            filtered_logs.append(log)

    return filtered_logs

def count_logs_by_level(logs: list[LogLine]) -> dict:
    return dict(Counter(log.level for log in logs))

def display_log_counts(counts: dict):
    print("Рівень логування | Кількість")
    print("-----------------|----------")

    for level, count in counts.items():
        print(f"{level:<16} | {count:<10}")

def display_log_filtered(logs: list[LogLine], level: str):
    print(f"\nДеталі логів для рівня {level.upper()}:")
    for log in logs:
        print(f"{log.date} {log.time} - {log.message}")

def main():
    try:
        path = sys.argv[1]
        level = None
        if len(sys.argv) == 3:
            level = sys.argv[2]

        display_log_counts(count_logs_by_level(parse_logs(path)))

        if level:
            display_log_filtered(filter_logs_by_level(parse_logs(path), level), level)
    except ValueError as e:
        print(e)

if __name__ == "__main__":
    main()