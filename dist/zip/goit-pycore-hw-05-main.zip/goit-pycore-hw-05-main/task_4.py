from functools import wraps

valid_commands = ["hello", "close", "exit", "add", "change", "all", "phone"]
contacts = {}

# Decorators for error handling
def args_error(func):
    @wraps(func)
    def inner(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except TypeError as e:
            command_name = func.__name__.split("_")[0]
            missed_args = e.args[0].split(": ")[-1]
            print(f"Insufficient arguments for '{command_name}' command. Please provide additional arguments: {missed_args}.")

    return inner

def key_error(func):
    @wraps(func)
    def inner(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except KeyError as e:
            command_name = func.__name__.split("_")[0]
            arg_name = e.args[0]
            print(f"Wrong key for '{command_name}' command. Contact with name '{arg_name}' does not exist.")

    return inner

def value_error(func):
    @wraps(func)
    def inner(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ValueError as e:
            command_name = func.__name__.split("_")[0]
            arg_name = e.args[0]
            print(f"Value error for '{command_name}' command. Contact with name '{arg_name}' already exists.")

    return inner

def parse_input(user_input):
    cmd, *args = user_input.split()
    cmd = cmd.strip().lower()
    return cmd, *args

@args_error
@value_error
def add_contact(name, phone):
    if name in contacts:
        raise ValueError(name)

    contacts[name] = phone

    print(f"Adding a contact: {name} {phone}")

@args_error
@key_error
def change_contact(name, phone):
    if name not in contacts:
        raise KeyError(name)

    contacts[name] = phone

    print(f"Changing a contact: {name} {phone}")

@args_error
@key_error
def phone_show(name):
    if name not in contacts:
        raise KeyError(name)

    phone = contacts[name]

    print(f"Phone number for {name}: {phone}")

def all_contacts():
    print("Showing all contacts:")
    for name, phone in contacts.items():
        print(f"{name}: {phone}")

def main():
    print("Welcome to the assistant bot!")
    while True:
        command_input = input("Enter a command >>> ").strip().lower()
        command, *args = parse_input(command_input)

        if command not in valid_commands:
            print("Invalid command. Please try again.")
            continue

        if command == "add":
            add_contact(*args)
        elif command == "change":
            change_contact(*args)
        elif command == "phone":
            phone_show(*args)
        elif command == "all":
            all_contacts()
        elif command == "hello":
            print("How can I help you?")
        elif command in ["close", "exit"]:
            print("Good bye!")
            break

if __name__ == "__main__":
    main()